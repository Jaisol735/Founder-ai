import React, { useState } from 'react';
import { Lightbulb, ArrowRight } from 'lucide-react';
import type { BusinessIdea } from '../types';

const IdeaValidation = () => {
  const [idea, setIdea] = useState('');
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<BusinessIdea | null>(null);

  const validateIdea = async () => {
    setLoading(true);
    try {
      const response = await fetch('YOUR_BACKEND_URL/api/validate-idea', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idea }),
      });
      const data = await response.json();
      setAnalysis(data);
    } catch (error) {
      console.error('Error validating idea:', error);
    }
    setLoading(false);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center mb-6">
          <Lightbulb className="h-8 w-8 text-indigo-600" />
          <h1 className="text-2xl font-bold ml-2">Idea Validation</h1>
        </div>
        
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Describe your business idea
          </label>
          <textarea
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            rows={4}
            value={idea}
            onChange={(e) => setIdea(e.target.value)}
            placeholder="E.g., A subscription-based meal planning app for busy professionals..."
          />
        </div>

        <button
          onClick={validateIdea}
          disabled={loading || !idea}
          className="flex items-center justify-center w-full px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 disabled:bg-gray-400"
        >
          {loading ? 'Analyzing...' : (
            <>
              Validate Idea
              <ArrowRight className="ml-2 h-4 w-4" />
            </>
          )}
        </button>

        {analysis && (
          <div className="mt-6 p-4 bg-gray-50 rounded-md">
            <h2 className="text-xl font-semibold mb-4">Analysis Results</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-medium text-gray-700">Market Potential</h3>
                <p className="text-gray-600">{analysis.analysis}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default IdeaValidation;