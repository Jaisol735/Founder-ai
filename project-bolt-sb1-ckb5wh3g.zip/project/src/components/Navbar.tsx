import React from 'react';
import { Link } from 'react-router-dom';
import { Rocket, Brain, MessageSquare, BarChart3, Lightbulb } from 'lucide-react';

const Navbar = () => {
  return (
    <nav className="bg-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link to="/" className="flex items-center">
              <Rocket className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-bold text-gray-800">FounderAI</span>
            </Link>
          </div>
          <div className="flex space-x-8">
            <Link to="/idea-validation" className="flex items-center text-gray-600 hover:text-indigo-600">
              <Brain className="h-5 w-5 mr-1" />
              <span>Idea Validation</span>
            </Link>
            <Link to="/business-idea" className="flex items-center text-gray-600 hover:text-indigo-600">
              <Lightbulb className="h-5 w-5 mr-1" />
              <span>Business Ideas</span>
            </Link>
            <Link to="/advisor" className="flex items-center text-gray-600 hover:text-indigo-600">
              <MessageSquare className="h-5 w-5 mr-1" />
              <span>AI Advisor</span>
            </Link>
            <Link to="/dashboard" className="flex items-center text-gray-600 hover:text-indigo-600">
              <BarChart3 className="h-5 w-5 mr-1" />
              <span>Dashboard</span>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;