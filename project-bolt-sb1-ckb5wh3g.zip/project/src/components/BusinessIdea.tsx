import React, { useState } from 'react';
import { Search, DollarSign, MapPin } from 'lucide-react';

const businessCases = [
  {
    type: 'Restaurant',
    minFund: 50000,
    locations: ['urban', 'suburban'],
    description: 'A modern restaurant focusing on healthy, locally-sourced ingredients. Perfect for urban areas with health-conscious demographics.',
    requirements: 'Kitchen equipment, licenses, staff, location rent',
    roi: '15-20% annually',
    challenges: 'High competition, staff management, food cost control',
    tips: 'Focus on unique cuisine or concept, strong social media presence, delivery options'
  },
  {
    type: 'E-commerce Store',
    minFund: 10000,
    locations: ['online'],
    description: 'Online retail business selling niche products. Low overhead with potential for rapid scaling.',
    requirements: 'Website, inventory, marketing budget',
    roi: '20-30% annually',
    challenges: 'Market competition, inventory management, customer acquisition',
    tips: 'Start with a specific niche, focus on SEO, excellent customer service'
  },
  {
    type: 'Tech Startup',
    minFund: 100000,
    locations: ['urban', 'online'],
    description: 'Software or app development company focusing on innovative solutions.',
    requirements: 'Development team, office space, marketing',
    roi: '50%+ potential with successful exit',
    challenges: 'High competition, technical talent acquisition, rapid market changes',
    tips: 'Focus on solving specific problems, build MVP quickly, seek mentorship'
  },
  {
    type: 'Fitness Center',
    minFund: 75000,
    locations: ['urban', 'suburban'],
    description: 'Modern gym with personal training and group classes.',
    requirements: 'Equipment, space rental, trainers, licenses',
    roi: '15-25% annually',
    challenges: 'Equipment maintenance, membership retention, staff management',
    tips: 'Offer unique classes, focus on community building, strong social media presence'
  },
  {
    type: 'Coffee Shop',
    minFund: 35000,
    locations: ['urban', 'suburban'],
    description: 'Specialty coffee shop with artisanal beverages and light food options.',
    requirements: 'Equipment, location rent, inventory, staff',
    roi: '10-15% annually',
    challenges: 'High competition, staff training, consistent quality',
    tips: 'Focus on quality beans, create inviting atmosphere, build regular customer base'
  },
  {
    type: 'Digital Marketing Agency',
    minFund: 15000,
    locations: ['online', 'urban'],
    description: 'Agency providing digital marketing services to businesses.',
    requirements: 'Office space (optional), software tools, team',
    roi: '25-35% annually',
    challenges: 'Client acquisition, keeping up with trends, talent management',
    tips: 'Start with a specific niche, build portfolio with small clients, network actively'
  },
  {
    type: 'Real Estate Investment',
    minFund: 200000,
    locations: ['urban', 'suburban', 'rural'],
    description: 'Property investment for rental income or renovation and sale.',
    requirements: 'Property purchase, renovation budget, legal fees',
    roi: '8-15% annually',
    challenges: 'Market fluctuations, property management, renovation costs',
    tips: 'Start with smaller properties, build network with realtors, focus on emerging areas'
  },
  {
    type: 'Food Truck',
    minFund: 40000,
    locations: ['urban', 'suburban'],
    description: 'Mobile food business with unique cuisine concept.',
    requirements: 'Truck, equipment, licenses, inventory',
    roi: '10-20% annually',
    challenges: 'Location permits, equipment maintenance, weather dependency',
    tips: 'Create unique menu, use social media for location updates, partner with events'
  },
  {
    type: 'Online Education Platform',
    minFund: 25000,
    locations: ['online'],
    description: 'Digital platform offering courses and educational content.',
    requirements: 'Platform development, content creation, marketing',
    roi: '30-40% potential',
    challenges: 'Content quality, user acquisition, platform maintenance',
    tips: 'Focus on specific skills, partner with experts, strong mobile experience'
  },
  {
    type: 'Consulting Business',
    minFund: 5000,
    locations: ['online', 'urban'],
    description: 'Professional consulting services in specific industry.',
    requirements: 'Expertise, network, basic office setup',
    roi: '40-60% potential',
    challenges: 'Client acquisition, establishing credibility, time management',
    tips: 'Focus on your expertise area, build strong network, create case studies'
  },
  {
    type: 'Dropshipping Business',
    minFund: 3000,
    locations: ['online'],
    description: 'Online retail without inventory management.',
    requirements: 'Website, marketing budget, supplier relationships',
    roi: '20-30% potential',
    challenges: 'Supplier reliability, customer service, market saturation',
    tips: 'Choose reliable suppliers, focus on niche products, excellent customer service'
  },
  {
    type: 'Mobile App',
    minFund: 50000,
    locations: ['online'],
    description: 'Mobile application development and launch.',
    requirements: 'Development team, marketing budget, ongoing maintenance',
    roi: '40-60% potential with successful launch',
    challenges: 'Development costs, user acquisition, app store competition',
    tips: 'Focus on solving specific problem, gather user feedback early, strong marketing'
  },
  {
    type: 'Subscription Box Service',
    minFund: 15000,
    locations: ['online'],
    description: 'Curated product subscription service.',
    requirements: 'Inventory, packaging, fulfillment system',
    roi: '25-35% annually',
    challenges: 'Product curation, customer retention, inventory management',
    tips: 'Start with specific niche, strong unboxing experience, engage community'
  },
  {
    type: 'Coworking Space',
    minFund: 150000,
    locations: ['urban'],
    description: 'Shared workspace for professionals and startups.',
    requirements: 'Location, furniture, amenities, staff',
    roi: '15-25% annually',
    challenges: 'Location costs, occupancy rates, facility management',
    tips: 'Choose accessible location, create community events, flexible membership options'
  },
  {
    type: 'Pet Services',
    minFund: 30000,
    locations: ['urban', 'suburban'],
    description: 'Pet care services including daycare, grooming, and boarding.',
    requirements: 'Location, equipment, staff, licenses',
    roi: '15-25% annually',
    challenges: 'Staff training, facility maintenance, liability management',
    tips: 'Focus on quality care, build trust with pet owners, offer multiple services'
  }
];

const BusinessIdea = () => {
  const [businessType, setBusinessType] = useState('');
  const [budget, setBudget] = useState('');
  const [location, setLocation] = useState('');
  const [recommendations, setRecommendations] = useState<typeof businessCases[0][]>([]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const budgetNum = parseInt(budget, 10);
    
    const filtered = businessCases.filter(business => {
      const matchesType = !businessType || business.type.toLowerCase().includes(businessType.toLowerCase());
      const matchesBudget = !budget || business.minFund <= budgetNum;
      const matchesLocation = !location || business.locations.includes(location.toLowerCase());
      return matchesType && matchesBudget && matchesLocation;
    });

    setRecommendations(filtered);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Find Your Perfect Business Idea</h1>
        <p className="text-gray-600">Tell us about your preferences and we'll recommend suitable business ideas.</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Business Type
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                value={businessType}
                onChange={(e) => setBusinessType(e.target.value)}
                placeholder="e.g., Restaurant, Tech, Retail"
                className="pl-10 w-full p-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Available Budget
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="number"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                placeholder="Enter your budget"
                className="pl-10 w-full p-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Preferred Location
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <select
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="pl-10 w-full p-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
              >
                <option value="">Select location</option>
                <option value="urban">Urban</option>
                <option value="suburban">Suburban</option>
                <option value="rural">Rural</option>
                <option value="online">Online</option>
              </select>
            </div>
          </div>
        </div>

        <button
          type="submit"
          className="mt-6 w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
        >
          Find Business Ideas
        </button>
      </form>

      {recommendations.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {recommendations.map((business, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-2">{business.type}</h2>
              <div className="space-y-3">
                <p className="text-gray-600">{business.description}</p>
                <div className="flex items-center text-gray-700">
                  <DollarSign className="h-5 w-5 mr-2 text-green-600" />
                  <span>Required Investment: ${business.minFund.toLocaleString()}</span>
                </div>
                <div className="flex items-center text-gray-700">
                  <MapPin className="h-5 w-5 mr-2 text-blue-600" />
                  <span>Suitable Locations: {business.locations.join(', ')}</span>
                </div>
                <div className="mt-4">
                  <h3 className="font-medium text-gray-900 mb-1">Requirements</h3>
                  <p className="text-gray-600">{business.requirements}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900 mb-1">Expected ROI</h3>
                  <p className="text-gray-600">{business.roi}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900 mb-1">Key Challenges</h3>
                  <p className="text-gray-600">{business.challenges}</p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900 mb-1">Pro Tips</h3>
                  <p className="text-gray-600">{business.tips}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default BusinessIdea;