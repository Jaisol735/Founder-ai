export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface BusinessIdea {
  name: string;
  description: string;
  analysis: string;
}