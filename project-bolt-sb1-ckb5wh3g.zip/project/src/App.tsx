import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import IdeaValidation from './components/IdeaValidation';
import AIAdvisor from './components/AIAdvisor';
import Dashboard from './components/Dashboard';
import BusinessIdea from './components/BusinessIdea';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <Routes>
          <Route path="/idea-validation" element={<IdeaValidation />} />
          <Route path="/advisor" element={<AIAdvisor />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/business-idea" element={<BusinessIdea />} />
          <Route path="/" element={
            <div className="max-w-7xl mx-auto px-4 py-12">
              <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Welcome to FounderAI
                </h1>
                <p className="text-xl text-gray-600 mb-8">
                  Your AI-powered co-founder for the entrepreneurial journey
                </p>
                <img
                  src="https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80"
                  alt="Entrepreneurship"
                  className="rounded-lg shadow-xl mx-auto max-w-3xl"
                />
              </div>
            </div>
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;